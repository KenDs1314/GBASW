#include "video_switch.h"
#include "../core/gba_core.h"

void VideoSwitch::init()
{
    m_win = nwindowGetDefault();
    framebufferCreate(&m_fb, m_win, 1280, 720, PIXEL_FORMAT_RGBA_8888, 2);
    framebufferMakeLinear(&m_fb);
}

void VideoSwitch::presentFrame(const uint16_t* src)
{
    uint32_t stride;
    uint32_t* dst = static_cast<uint32_t*>(framebufferBegin(&m_fb, &stride));

    // Escala nearest-neighbor de 240x160 (GBA) a 1280x720 manteniendo aspecto 3:2,
    // centrado con barras negras a los costados.
    const int outW = 1280, outH = 720;
    const int scale = outH / GBA_HEIGHT;              // escala entera por alto
    const int drawW = GBA_WIDTH * scale;
    const int drawH = GBA_HEIGHT * scale;
    const int offX = (outW - drawW) / 2;
    const int offY = (outH - drawH) / 2;

    for (int y = 0; y < outH; y++)
    {
        uint32_t* row = dst + y * (stride / sizeof(uint32_t));
        for (int x = 0; x < outW; x++)
        {
            uint32_t color = 0xFF000000; // negro opaco por defecto (barras)

            int gx = x - offX, gy = y - offY;
            if (gx >= 0 && gx < drawW && gy >= 0 && gy < drawH)
            {
                int srcX = gx / scale, srcY = gy / scale;
                uint16_t px = src[srcY * GBA_WIDTH + srcX];

                uint8_t r = ((px >> 11) & 0x1F) * 255 / 31;
                uint8_t g = ((px >> 5)  & 0x3F) * 255 / 63;
                uint8_t b = (px         & 0x1F) * 255 / 31;
                color = 0xFF000000 | (b << 16) | (g << 8) | r;
            }
            row[x] = color;
        }
    }

    framebufferEnd(&m_fb);
}

void VideoSwitch::exit()
{
    framebufferClose(&m_fb);
}
